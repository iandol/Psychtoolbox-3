% collection of essential functions for the eyelink toolbox
% EyelinkToolbox:EyelinkBasic
